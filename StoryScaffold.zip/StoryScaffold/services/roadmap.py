import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

client = Groq(
    api_key=os.getenv("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")
)


def generate_roadmap(business):

    prompt = f"""
You are StoryScaffold AI Business Growth Consultant.

Create a detailed business growth roadmap for the business below.

Business Information:

{business}

Generate the report with the following sections:

1. Business Goal

2. Current Situation Analysis

3. 30-Day Action Plan

4. 60-Day Action Plan

5. 90-Day Action Plan

6. Website Improvement Plan

7. SEO Strategy

8. Social Media Marketing Strategy

9. Content Marketing Ideas

10. Customer Engagement Strategy

11. Budget Recommendations

12. Key Performance Indicators (KPIs)

13. Risks and Challenges

14. Future Expansion Ideas

15. Final Success Strategy

Return the report in a professional format with headings and bullet points.
"""

    response = client.chat.completions.create(

        model="llama-3.3-70b-versatile",

        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]

    )

    return response.choices[0].message.content