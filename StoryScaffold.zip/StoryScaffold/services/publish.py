import os
from datetime import datetime

# ==========================================
# GENERATED FOLDER
# ==========================================

GENERATED_FOLDER = "generated"

if not os.path.exists(GENERATED_FOLDER):
    os.makedirs(GENERATED_FOLDER)


# ==========================================
# SAVE WEBSITE
# ==========================================

def publish_website(website_name, html):

    filename = website_name.lower().replace(" ", "_") + ".html"

    filepath = os.path.join(

        GENERATED_FOLDER,

        filename

    )

    with open(

        filepath,

        "w",

        encoding="utf-8"

    ) as file:

        file.write(html)

    return {

        "filename": filename,

        "url": "/generated/" + filename,

        "date": datetime.now().strftime(

            "%d-%m-%Y %I:%M %p"

        )

    }


# ==========================================
# DELETE WEBSITE
# ==========================================

def delete_website(website_name):

    filename = website_name.lower().replace(

        " ",

        "_"

    ) + ".html"

    filepath = os.path.join(

        GENERATED_FOLDER,

        filename

    )

    if os.path.exists(filepath):

        os.remove(filepath)

        return {

            "success": True,

            "message": "Website Deleted Successfully"

        }

    return {

        "success": False,

        "message": "Website Not Found"

    }


# ==========================================
# GENERATE PREVIEW IMAGE
# ==========================================

def generate_website_image(data):

    """
    Temporary placeholder.
    You can later replace this with
    AI screenshot generation.
    """

    return "preview.png"