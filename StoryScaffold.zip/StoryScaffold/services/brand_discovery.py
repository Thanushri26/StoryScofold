import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

client = Groq(
    api_key=os.getenv("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")
)


def generate_brand(business):

    prompt = f"""
You are StoryScaffold AI.

The user wants to build a professional business brand.

Based on the following business description generate:

1. Business Name
2. Brand Tagline
3. Brand Personality
4. Brand Colors
5. Font Style
6. Logo Idea
7. Mission Statement
8. Vision Statement
9. Brand Description

Business:

{business}

Return the answer in a neat format.
"""

    response = client.chat.completions.create(

        model="llama-3.3-70b-versatile",

        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]

    )

    return response.choices[0].message.content