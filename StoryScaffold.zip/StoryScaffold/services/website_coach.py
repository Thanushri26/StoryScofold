import os

from groq import Groq

from dotenv import load_dotenv

load_dotenv()

client = Groq(
    api_key=os.getenv("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")
)


def ask_ai(question):

    try:

        response = client.chat.completions.create(

            model="llama-3.3-70b-versatile",

            messages=[

                {
                    "role": "system",
                    "content": "You are an expert AI Website Designer."
                },

                {
                    "role": "user",
                    "content": question
                }

            ],

            temperature=0.7,

            max_tokens=7000

        )

        return response.choices[0].message.content

    except Exception as e:

        print("Groq Error:", e)

        return ""