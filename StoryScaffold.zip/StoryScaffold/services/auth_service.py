from models.user import User


class AuthService:


    @staticmethod
    def register(data):
        """
        Register new user
        """

        email = data.get("email")
        username = data.get("username")


        # Check existing email
        existing_email = User.find_by_email(email)

        if existing_email:
            return {
                "success": False,
                "message": "Email already exists"
            }


        # Check existing username
        existing_username = User.find_by_username(username)

        if existing_username:
            return {
                "success": False,
                "message": "Username already exists"
            }


        # Save user
        User.register_user(data)


        return {
            "success": True,
            "message": "Registration successful"
        }



    @staticmethod
    def login(email, password):
        """
        Login verification
        """

        user = User.login_user(email, password)


        if user:

            return {
                "success": True,
                "message": "Login successful",
                "user": {
                    "username": user["username"],
                    "email": user["email"]
                }
            }


        return {
            "success": False,
            "message": "Invalid email or password"
        }



    @staticmethod
    def forgot_password(email):

        """
        Forgot password checking
        """

        user = User.find_by_email(email)


        if user:

            return {
                "success": True,
                "message": "User found. Password reset process started"
            }


        return {
            "success": False,
            "message": "Email not found"
        }