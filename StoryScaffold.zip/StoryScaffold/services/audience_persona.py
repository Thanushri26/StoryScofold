import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)


def generate_persona(business):

    prompt = f"""
You are StoryScaffold AI Audience Persona Expert.

Based on the business description below, generate a complete customer persona.

Include:

1. Target Age Group
2. Gender (if applicable)
3. Occupation
4. Income Level
5. Interests
6. Goals
7. Pain Points
8. Buying Behaviour
9. Preferred Social Media Platforms
10. Marketing Strategy
11. Best Content Ideas
12. Communication Style

Business Description:

{business}

Return the response in a neat and professional format.
"""

    response = client.chat.completions.create(

        model="llama-3.3-70b-versatile",

        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]

    )

    return response.choices[0].message.content