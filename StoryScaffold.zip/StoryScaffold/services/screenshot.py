from playwright.sync_api import sync_playwright
import os


def create_image():


    html_path = os.path.abspath(
        "static/generated/website.html"
    )


    with sync_playwright() as p:

        browser = p.chromium.launch(
            headless=True
        )


        page = browser.new_page(
            viewport={
                "width":1200,
                "height":900
            }
        )


        page.goto(
            "file:///" + html_path
        )


        page.screenshot(
            path="static/generated/website.png",
            full_page=True
        )


        browser.close()


    return "website.png"