import requests
from bs4 import BeautifulSoup
from services.website_coach import ask_ai


# ==========================================
# Extract Website Features
# ==========================================

def extract_website(url):

    try:

        response = requests.get(
            url,
            timeout=10,
            headers={
                "User-Agent": "Mozilla/5.0"
            }
        )

        soup = BeautifulSoup(
            response.text,
            "html.parser"
        )

        features = {}

        features["title"] = (
            soup.title.text.strip()
            if soup.title else "No Title"
        )

        features["navbar"] = (
            soup.find("nav") is not None
        )

        features["footer"] = (
            soup.find("footer") is not None
        )

        features["form"] = (
            soup.find("form") is not None
        )

        features["hero"] = (
            soup.find("header") is not None
        )

        features["buttons"] = len(
            soup.find_all("button")
        )

        features["images"] = len(
            soup.find_all("img")
        )

        features["links"] = len(
            soup.find_all("a")
        )

        features["inputs"] = len(
            soup.find_all("input")
        )

        features["sections"] = len(
            soup.find_all("section")
        )

        features["cards"] = len(
            soup.find_all(class_="card")
        )

        features["tables"] = len(
            soup.find_all("table")
        )

        features["videos"] = len(
            soup.find_all("video")
        )

        features["social_links"] = any(

            "facebook" in a.get("href","") or
            "instagram" in a.get("href","") or
            "twitter" in a.get("href","") or
            "linkedin" in a.get("href","")

            for a in soup.find_all("a")
        )

        features["responsive"] = (

            soup.find(
                "meta",
                attrs={
                    "name":"viewport"
                }
            ) is not None

        )

        return features

    except Exception as e:

        return {

            "error": str(e)

        }


# ==========================================
# Compare Features
# ==========================================

def compare(my, comp):

    score = 0

    total = 10

    result = {}

    bool_features = [

        "navbar",
        "footer",
        "form",
        "hero",
        "social_links",
        "responsive"

    ]

    for feature in bool_features:

        if my.get(feature) == comp.get(feature):

            score += 1

            result[feature] = "✔ Available"

        else:

            result[feature] = "✖ Different"

    number_features = [

        "buttons",
        "images",
        "links",
        "sections"

    ]

    for feature in number_features:

        my_value = my.get(feature,0)

        comp_value = comp.get(feature,0)

        difference = abs(my_value-comp_value)

        if difference <= 2:

            score += 1

        result[feature] = {

            "mine": my_value,

            "competitor": comp_value

        }

    similarity = round(

        (score/total)*100

    )

    return similarity,result


# ==========================================
# Main Function
# ==========================================

def generate_competitor(

    my_url,

    competitor_url

):

    my_data = extract_website(my_url)

    competitor_data = extract_website(competitor_url)

    if "error" in my_data:

        return my_data["error"]

    if "error" in competitor_data:

        return competitor_data["error"]

    similarity, comparison = compare(

        my_data,

        competitor_data

    )

    prompt = f"""

Website Similarity : {similarity}%

Comparison

{comparison}

Give only:

Strengths

Weaknesses

Recommendations

Use bullet points only.

"""

    ai = ask_ai(prompt)

    return {

        "similarity": similarity,

        "comparison": comparison,

        "ai": ai

    }