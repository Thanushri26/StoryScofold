import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)


def chatbot_reply(question):

    prompt = f"""
You are StoryScaffold AI Assistant.

You help users with:

• Website Development
• Business Ideas
• Branding
• Marketing
• SEO
• Audience Persona
• Website Builder
• Business Readiness
• Website Health
• Competitor Analysis
• Growth Roadmap
• HTML
• CSS
• JavaScript
• Flask
• Python
• SQLite

Always answer professionally.

If possible, give:
- Short explanation
- Bullet points
- Tips
- Best practices

User Question:

{question}
"""

    response = client.chat.completions.create(

        model="llama-3.3-70b-versatile",

        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]

    )

    return response.choices[0].message.content