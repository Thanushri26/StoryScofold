import os
from dotenv import load_dotenv
from openai import OpenAI


load_dotenv()


client = OpenAI(
    api_key=os.getenv("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")
)



def ask_ai(prompt):

    try:

        response = client.chat.completions.create(

            model="gpt-4o-mini",

            messages=[
                {
                    "role": "system",
                    "content": 
                    "You are an expert AI website builder assistant."
                },

                {
                    "role": "user",
                    "content": prompt
                }
            ]

        )


        return response.choices[0].message.content


    except Exception as e:

        print("AI ERROR:", e)

        return ""