import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

client = Groq(
    api_key=os.getenv("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")
)


def generate_health(website):

    prompt = f"""
You are StoryScaffold AI Website Health Analyzer.

Analyze the following business/website details.

Website Details:

{website}

Generate a professional report containing:

1. Overall Website Health Score (0-100%)

2. SEO Score

3. Performance Score

4. Mobile Friendliness

5. User Experience

6. Accessibility

7. Website Security

8. Loading Speed Analysis

9. Content Quality

10. Strengths

11. Weaknesses

12. Top 5 Improvements

13. Final Recommendation

Return the report in a clean and professional format.
"""

    response = client.chat.completions.create(

        model="llama-3.3-70b-versatile",

        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]

    )

    return response.choices[0].message.content