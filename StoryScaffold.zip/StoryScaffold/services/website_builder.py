from services.website_coach import ask_ai
import os


# ==========================================
# GENERATE WEBSITE
# ==========================================

def generate_website(data):

    website_name = data.get("websiteName", "")

    business_name = data.get("businessName", "")

    business_type = data.get("businessType", "")

    theme = data.get("theme", "")

    primary_color = data.get("primaryColor", "#2563eb")

    secondary_color = data.get("secondaryColor", "#0f172a")

    audience = data.get("audience", "")

    description = data.get("description", "")

    features = ", ".join(data.get("features", []))


    prompt = f"""
You are an expert UI/UX Designer and Professional Web Developer.

Create a COMPLETELY UNIQUE website.

Business Details

Website Name:
{website_name}

Business Name:
{business_name}

Business Type:
{business_type}

Theme:
{theme}

Primary Color:
{primary_color}

Secondary Color:
{secondary_color}

Target Audience:
{audience}

Business Description:
{description}

Required Sections:
{features}

Requirements

1. Return ONLY HTML.

2. Put ALL CSS inside <style>.

3. Do NOT return markdown.

4. Do NOT explain anything.

5. Create a modern responsive website.

6. Include:
- Navigation Bar
- Hero Section
- About
- Services
- Feature Cards
- Contact Section
- Footer

7. Use the selected colors.

8. Add hover animations.

9. Add beautiful buttons.

10. Every website should have a different layout.

11. Make it look like a professional company website.
"""

    html = ask_ai(prompt)

    # Remove markdown if AI returns it
    html = html.replace("```html", "")
    html = html.replace("```", "")

    # ===============================
    # Save Generated Website
    # ===============================

    os.makedirs("generated", exist_ok=True)

    filename = website_name.lower().replace(" ", "_") + ".html"

    filepath = os.path.join("generated", filename)

    with open(filepath, "w", encoding="utf-8") as file:

        file.write(html)

    return html