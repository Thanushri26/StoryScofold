import os



def save_html(html_code):


    folder = "static/generated"


    os.makedirs(
        folder,
        exist_ok=True
    )


    file_path = (
        folder +
        "/website.html"
    )


    with open(
        file_path,
        "w",
        encoding="utf-8"
    ) as file:


        file.write(
            html_code
        )


    return file_path