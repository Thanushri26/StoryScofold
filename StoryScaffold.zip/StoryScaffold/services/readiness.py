import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

client = Groq(
    api_key=os.getenv("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")
)


def generate_readiness(business):

    prompt = f"""
You are StoryScaffold AI Business Consultant.

Analyze the following business and generate a Business Readiness Report.

Business Details:

{business}

Generate the following:

1. Business Readiness Score (0-100%)

2. Strengths

3. Weaknesses

4. Missing Requirements

5. Website Readiness

6. Digital Marketing Readiness

7. Branding Readiness

8. Customer Engagement Readiness

9. Security Suggestions

10. Top 5 Recommendations

11. Final Conclusion

Return the report in a professional format.
"""

    response = client.chat.completions.create(

        model="llama-3.3-70b-versatile",

        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]

    )

    return response.choices[0].message.content