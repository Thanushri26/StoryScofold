document.addEventListener("DOMContentLoaded", () => {

    console.log("StoryScaffold Loaded");

});



async function registerUser(){

    let username = document.getElementById("username").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;


    let response = await fetch("/register",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify({

            username:username,
            email:email,
            password:password

        })

    });


    let data = await response.json();

    alert(data.message);

}



async function loginUser(){

    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;


    let response = await fetch("/login",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify({

            email:email,
            password:password

        })

    });


    let data = await response.json();


    alert(data.message);


    if(data.message === "Login successful"){

        window.location.href="/dashboard";

    }

}