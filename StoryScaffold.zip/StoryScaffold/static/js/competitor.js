async function analyze() {

    const myURL = document.getElementById("myURL").value.trim();

    const competitorURL = document.getElementById("competitorURL").value.trim();

    if (myURL === "" || competitorURL === "") {

        alert("Please enter both website URLs.");

        return;
    }

    document.getElementById("result").style.display = "block";

    document.getElementById("comparisonBody").innerHTML =
        "<tr><td colspan='3'>Analyzing websites...</td></tr>";

    document.getElementById("aiResult").innerHTML = "Generating AI recommendations...";

    try {

        const response = await fetch("/generate-competitor", {

            method: "POST",

            headers: {

                "Content-Type": "application/json"

            },

            body: JSON.stringify({

                myBusiness: myURL,

                competitorBusiness: competitorURL

            })

        });

        const data = await response.json();

        // -----------------------------
        // Similarity
        // -----------------------------

        document.getElementById("similarity").innerHTML =
            data.answer.similarity + "%";

        document.getElementById("competition").innerHTML =
            (100 - data.answer.similarity) + "%";

        // -----------------------------
        // AI Recommendation
        // -----------------------------

        document.getElementById("aiResult").innerHTML =
            data.answer.ai;

        // -----------------------------
        // Feature Table
        // -----------------------------

        let html = "";

        let count = 0;

        for (let key in data.answer.comparison) {

            let row = data.answer.comparison[key];

            count++;

            if (typeof row === "object") {

                html += `
                <tr>
                    <td>${key}</td>
                    <td>${row.mine}</td>
                    <td>${row.competitor}</td>
                </tr>
                `;

            }

            else {

                html += `
                <tr>
                    <td>${key}</td>
                    <td colspan="2">${row}</td>
                </tr>
                `;

            }

        }

        document.getElementById("comparisonBody").innerHTML = html;

        document.getElementById("features").innerHTML = count;

    }

    catch (error) {

        document.getElementById("comparisonBody").innerHTML =
            "<tr><td colspan='3'>Error while comparing websites.</td></tr>";

        document.getElementById("aiResult").innerHTML = error;

    }

}