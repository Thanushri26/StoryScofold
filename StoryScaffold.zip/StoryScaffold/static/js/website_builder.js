// ==========================================
// GLOBAL VARIABLE
// ==========================================

let generatedHTML = "";


// ==========================================
// GENERATE WEBSITE
// ==========================================

async function generateWebsite() {

    const websiteName = document.getElementById("websiteName").value;

    const businessName = document.getElementById("businessName").value;

    const businessType = document.getElementById("businessType").value;

    const theme = document.getElementById("theme").value;

    const primaryColor = document.getElementById("primaryColor").value;

    const secondaryColor = document.getElementById("secondaryColor").value;

    const audience = document.getElementById("audience").value;

    const description = document.getElementById("description").value;

    const features = [];

    document.querySelectorAll(".features input:checked").forEach(item=>{

        features.push(item.value);

    });


    if(

        websiteName=="" ||

        businessName=="" ||

        description==""

    ){

        alert("Please fill all required fields.");

        return;

    }


    document.getElementById("summary").innerHTML="⏳ Generating AI Website...";


    try{

        const response = await fetch("/generate-website",{

            method:"POST",

            headers:{

                "Content-Type":"application/json"

            },

            body:JSON.stringify({

                websiteName,

                businessName,

                businessType,

                theme,

                primaryColor,

                secondaryColor,

                audience,

                description,

                features

            })

        });


        const data = await response.json();

        generatedHTML = data.answer;


        // Preview

        const frame = document.getElementById("previewFrame");

        frame.srcdoc = generatedHTML;


        // Summary

        document.getElementById("summary").innerHTML=

        "<b>Website Name:</b> "+websiteName+

        "<br><br>"+

        "<b>Business:</b> "+businessName+

        "<br><br>"+

        "<b>Theme:</b> "+theme+

        "<br><br>"+

        "<b>Audience:</b> "+audience+

        "<br><br>"+

        "✅ Website Generated Successfully.";


        // Save temporarily

        localStorage.setItem(

            "generatedWebsite",

            generatedHTML

        );

        localStorage.setItem(

            "websiteName",

            websiteName

        );

        localStorage.setItem(

            "businessName",

            businessName

        );


    }

    catch(error){

        console.log(error);

        alert("Error generating website.");

    }

}



// ==========================================
// DOWNLOAD HTML
// ==========================================

function downloadHTML(){

    if(generatedHTML==""){

        alert("Generate website first.");

        return;

    }


    const blob = new Blob(

        [generatedHTML],

        {

            type:"text/html"

        }

    );


    const link = document.createElement("a");

    link.href = URL.createObjectURL(blob);

    link.download =

    localStorage.getItem("websiteName")+".html";

    link.click();

}



// ==========================================
// GO TO PUBLISH PAGE
// ==========================================

function goPublish(){

    if(generatedHTML==""){

        alert("Generate website first.");

        return;

    }

    window.location.href="/publish";

}