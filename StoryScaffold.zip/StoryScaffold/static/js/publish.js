window.onload=function(){

    document.getElementById("websiteName").value=

    localStorage.getItem("websiteName");

    document.getElementById("businessName").value=

    localStorage.getItem("businessName");

    let html=

    localStorage.getItem("generatedWebsite");

    document.getElementById("previewFrame").srcdoc=

    html;

}



// Download

function downloadHTML(){

    let html=

    localStorage.getItem("generatedWebsite");

    if(!html){

        alert("No generated website found.");

        return;

    }

    let blob=new Blob(

        [html],

        {

            type:"text/html"

        }

    );

    let a=document.createElement("a");

    a.href=URL.createObjectURL(blob);

    a.download=

    localStorage.getItem("websiteName")+".html";

    a.click();

}



// Publish

function publishWebsite(){

    document.getElementById("publishStatus").innerHTML=`

    <div class="success">

        <h2>✅ Website Published Successfully</h2>

        <br>

        <b>Project :</b>

        ${localStorage.getItem("websiteName")}

        <br><br>

        <b>Status :</b>

        Published

        <br><br>

        <b>Generated File :</b>

        generated/${localStorage.getItem("websiteName").toLowerCase().replaceAll(" ","_")}.html

    </div>

    `;

}