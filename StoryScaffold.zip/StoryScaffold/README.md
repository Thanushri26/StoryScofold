# StoryScaffold

AI-powered website building and business growth platform.

## Features

- User Registration and Login
- AI Chatbot
- Website Builder
- Competitor Analysis
- Growth Roadmap
- Dashboard


## Backend Setup

Install dependencies:
