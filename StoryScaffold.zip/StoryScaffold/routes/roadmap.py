from flask import Blueprint, request, jsonify
from services.roadmap_service import RoadmapService


roadmap = Blueprint("roadmap", __name__)


@roadmap.route("/roadmap/save", methods=["POST"])
def save_roadmap():

    data = request.json

    RoadmapService.save_roadmap(data)

    return jsonify({
        "message": "Roadmap saved"
    })



@roadmap.route("/roadmap/<user_id>", methods=["GET"])
def get_roadmap(user_id):

    data = RoadmapService.get_roadmap(user_id)

    return jsonify(data if data else {})



@roadmap.route("/roadmap/update/<user_id>", methods=["PUT"])
def update_roadmap(user_id):

    data = request.json

    RoadmapService.update_roadmap(user_id, data)

    return jsonify({
        "message": "Roadmap updated"
    })