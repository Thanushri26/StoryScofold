from flask import Blueprint, request, jsonify
from models.website import Website


website = Blueprint("website", __name__)


@website.route("/website/save", methods=["POST"])
def save_website():

    data = request.json

    Website.save_website(data)

    return jsonify({
        "message": "Website data saved"
    })



@website.route("/website/<user_id>", methods=["GET"])
def get_website(user_id):

    data = Website.get_website(user_id)

    return jsonify(data if data else {})



@website.route("/website/update/<user_id>", methods=["PUT"])
def update_website(user_id):

    data = request.json

    Website.update_website(user_id, data)

    return jsonify({
        "message": "Website updated"
    })



@website.route("/website/delete/<user_id>", methods=["DELETE"])
def delete_website(user_id):

    Website.delete_website(user_id)

    return jsonify({
        "message": "Website deleted"
    })