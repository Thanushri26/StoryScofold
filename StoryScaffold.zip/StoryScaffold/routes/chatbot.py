from flask import Blueprint, request, jsonify
from models.chat import Chat
from services.ai_service import AIService


chatbot = Blueprint("chatbot", __name__)


@chatbot.route("/chat", methods=["POST"])
def chat():

    data = request.json

    user_id = data.get("user_id")
    message = data.get("message")


    reply = AIService.generate_response(message)


    Chat.save_message({
        "user_id": user_id,
        "message": message,
        "reply": reply
    })


    return jsonify({
        "reply": reply
    })



@chatbot.route("/chat/<user_id>", methods=["GET"])
def get_chat(user_id):

    messages = Chat.get_chat(user_id)

    return jsonify(messages)