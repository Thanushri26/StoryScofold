from flask import Blueprint, jsonify
from models.user import User


dashboard = Blueprint("dashboard", __name__)


@dashboard.route("/dashboard/<email>", methods=["GET"])
def get_dashboard(email):

    user = User.find_by_email(email)

    if user:

        return jsonify({
            "username": user.get("username"),
            "email": user.get("email")
        })


    return jsonify({
        "message": "User not found"
    })