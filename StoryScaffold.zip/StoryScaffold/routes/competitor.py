from flask import Blueprint, request, jsonify
from services.competitor_service import CompetitorService


competitor = Blueprint("competitor", __name__)


@competitor.route("/competitor/save", methods=["POST"])
def save_competitor():

    data = request.json

    CompetitorService.save_analysis(data)

    return jsonify({
        "message": "Competitor analysis saved"
    })



@competitor.route("/competitor/<user_id>", methods=["GET"])
def get_competitor(user_id):

    data = CompetitorService.get_analysis(user_id)

    return jsonify(data if data else {})



@competitor.route("/competitor/update/<user_id>", methods=["PUT"])
def update_competitor(user_id):

    data = request.json

    CompetitorService.update_analysis(user_id, data)

    return jsonify({
        "message": "Competitor analysis updated"
    })