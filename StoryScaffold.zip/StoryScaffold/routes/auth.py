from flask import Blueprint, request, jsonify
from models.user import User


auth = Blueprint("auth", __name__)


@auth.route("/register", methods=["POST"])
def register():

    data = request.json

    if User.find_by_email(data["email"]):
        return jsonify({
            "message": "Email already exists"
        })


    User.create_user(data)

    return jsonify({
        "message": "Registration successful"
    })



@auth.route("/login", methods=["POST"])
def login():

    data = request.json

    user = User.verify_login(
        data["email"],
        data["password"]
    )


    if user:
        return jsonify({
            "message": "Login successful",
            "user": user["username"]
        })


    return jsonify({
        "message": "Invalid credentials"
    })



@auth.route("/forgot-password", methods=["POST"])
def forgot_password():

    data = request.json

    user = User.find_by_email(data["email"])


    if user:
        return jsonify({
            "message": "Email found"
        })


    return jsonify({
        "message": "Email not found"
    })