from flask import Flask, render_template, request, jsonify, send_from_directory
from dotenv import load_dotenv

from config import Config


# ==========================
# AI SERVICES
# ==========================

from services.website_coach import ask_ai
from services.chatbot import chatbot_reply
from services.brand_discovery import generate_brand
from services.audience_persona import generate_persona
from services.website_builder import generate_website
from services.readiness import generate_readiness
from services.health import generate_health
from services.competitor import generate_competitor
from services.roadmap import generate_roadmap


# ==========================
# PUBLISH SERVICES
# ==========================

from services.publish import (
    generate_website_image,
    publish_website,
    delete_website
)



# ==========================
# ENV
# ==========================

load_dotenv()


app = Flask(__name__)

app.config.from_object(Config)



# ==========================
# HOME
# ==========================

@app.route("/")
def home():

    return render_template("index.html")



# ==========================
# LOGIN REGISTER
# ==========================

@app.route("/login")
def login():

    return render_template("login.html")



@app.route("/register")
def register():

    return render_template("register.html")



# ==========================
# DASHBOARD
# ==========================

@app.route("/dashboard")
def dashboard():

    return render_template("dashboard.html")



# ==========================
# CHATBOT
# ==========================

@app.route("/chatbot")
def chatbot():

    return render_template("chatbot.html")



@app.route("/ask-chatbot", methods=["POST"])
def ask_chatbot():

    data = request.get_json()

    answer = chatbot_reply(
        data["question"]
    )

    return jsonify({
        "answer": answer
    })



# ==========================
# WEBSITE COACH
# ==========================

@app.route("/website-coach")
def website_coach():

    return render_template(
        "website_coach.html"
    )



@app.route("/ask-ai", methods=["POST"])
def ask_ai_route():

    data = request.get_json()

    answer = ask_ai(
        data["question"]
    )

    return jsonify({
        "answer": answer
    })



# ==========================
# BRAND DISCOVERY
# ==========================

@app.route("/brand-discovery")
def brand_discovery():

    return render_template(
        "brand_discovery.html"
    )



@app.route("/generate-brand", methods=["POST"])
def generate_brand_route():

    data = request.get_json()

    answer = generate_brand(
        data["business"]
    )

    return jsonify({
        "answer": answer
    })



# ==========================
# AUDIENCE PERSONA
# ==========================

@app.route("/audience-persona")
def audience_persona():

    return render_template(
        "audience_persona.html"
    )



@app.route("/generate-persona", methods=["POST"])
def generate_persona_route():

    data = request.get_json()

    answer = generate_persona(
        data["business"]
    )

    return jsonify({
        "answer": answer
    })



# ==========================
# WEBSITE BUILDER
# ==========================

@app.route("/website-builder")
def website_builder():

    return render_template(
        "website_builder.html"
    )


@app.route(
    "/generate-website",
    methods=["POST"]
)
def generate_website_route():

    data = request.get_json()

    answer = generate_website(data)

    return jsonify({

        "answer": answer

    })


# ==========================
# READINESS
# ==========================

@app.route("/readiness")
def readiness():

    return render_template(
        "readiness.html"
    )


@app.route("/generate-readiness", methods=["POST"])
def generate_readiness_route():

    data = request.get_json()

    answer = generate_readiness(
        data["business"]
    )

    return jsonify({
        "answer": answer
    })



# ==========================
# HEALTH
# ==========================

@app.route("/health")
def health():

    return render_template(
        "health.html"
    )



@app.route("/generate-health", methods=["POST"])
def generate_health_route():

    data = request.get_json()

    answer = generate_health(
        data["website"]
    )

    return jsonify({
        "answer": answer
    })



# ==========================
# COMPETITOR
# ==========================

@app.route("/competitor")
def competitor():

    return render_template(
        "competitor.html"
    )



@app.route("/generate-competitor", methods=["POST"])
def generate_competitor_route():

    data = request.get_json()


    answer = generate_competitor(

        data["myBusiness"],

        data["competitorBusiness"]

    )


    return jsonify({

        "answer": answer

    })



# ==========================
# ROADMAP
# ==========================

@app.route("/roadmap")
def roadmap():

    return render_template(
        "roadmap.html"
    )



@app.route("/generate-roadmap", methods=["POST"])
def generate_roadmap_route():

    data = request.get_json()

    answer = generate_roadmap(
        data["business"]
    )

    return jsonify({

        "answer": answer

    })



# ==========================
# PUBLISH
# ==========================

@app.route("/publish")
def publish():

    return render_template(
        "publish.html"
    )



@app.route("/generate-design-image", methods=["POST"])
def generate_design_image():

    data = request.get_json()


    image = generate_website_image(
        data
    )


    return jsonify({

        "image":

        "/static/generated/" + image

    })



@app.route("/publish-website", methods=["POST"])
def publish_site():

    data = request.get_json()


    result = publish_website(

        data["websiteName"],

        data["html"]

    )


    return jsonify(result)



@app.route("/delete-website", methods=["POST"])
def delete_site():

    data = request.get_json()


    result = delete_website(

        data["websiteName"]

    )


    return jsonify(result)



# ==========================
# ADMIN
# ==========================

@app.route("/admin")
def admin():

    return render_template(
        "admin.html"
    )



# ==========================
# RUN
# ==========================

if __name__ == "__main__":

    app.run(
        debug=True
    )