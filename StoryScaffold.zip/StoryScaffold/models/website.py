from services.mongo_service import website_collection


class Website:


    @staticmethod
    def save_website(data):
        return website_collection.insert_one(data)


    @staticmethod
    def get_website(user_id):
        return website_collection.find_one({
            "user_id": user_id
        })


    @staticmethod
    def update_website(user_id, data):
        return website_collection.update_one(
            {"user_id": user_id},
            {"$set": data}
        )


    @staticmethod
    def delete_website(user_id):
        return website_collection.delete_one({
            "user_id": user_id
        })