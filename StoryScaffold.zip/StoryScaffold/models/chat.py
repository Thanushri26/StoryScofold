from services.mongo_service import chat_collection


class Chat:


    @staticmethod
    def save_message(data):
        return chat_collection.insert_one(data)


    @staticmethod
    def get_chat(user_id):

        return list(chat_collection.find({
            "user_id": user_id
        }))


    @staticmethod
    def delete_chat(user_id):

        return chat_collection.delete_many({
            "user_id": user_id
        })