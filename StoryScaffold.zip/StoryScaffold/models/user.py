from services.mongo_service import users_collection


class User:

    @staticmethod
    def create_user(data):
        return users_collection.insert_one(data)


    @staticmethod
    def find_by_email(email):
        return users_collection.find_one({
            "email": email
        })


    @staticmethod
    def find_by_username(username):
        return users_collection.find_one({
            "username": username
        })


    @staticmethod
    def verify_login(email, password):
        return users_collection.find_one({
            "email": email,
            "password": password
        })


    @staticmethod
    def update_user(email, data):
        return users_collection.update_one(
            {"email": email},
            {"$set": data}
        )


    @staticmethod
    def delete_user(email):
        return users_collection.delete_one({
            "email": email
        })