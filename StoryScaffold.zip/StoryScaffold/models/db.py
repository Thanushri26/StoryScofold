from pymongo import MongoClient
from config import Config

client = MongoClient(Config.MONGO_URI)

db = client["StoryScaffold"]

users = db["users"]

website_data = db["website_data"]

competitor_data = db["competitor_data"]